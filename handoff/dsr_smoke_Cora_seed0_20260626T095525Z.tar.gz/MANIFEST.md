# Research Output Manifest

> Auto-maintained by ARIS skills. Tracks generated artifacts across the research lifecycle.

| Timestamp | Skill | File | Stage | Description |
|-----------|-------|------|-------|-------------|
| 2026-06-26 08:34 | /idea-discovery | idea-stage/BCE_GCL_NOVELTY_BRIEF_20260626_083442.md | idea-discovery | BCE-GCL novelty reviewer brief |
| 2026-06-26 08:34 | /idea-discovery | idea-stage/BCE_GCL_NOVELTY_BRIEF.md | idea-discovery | latest BCE-GCL novelty brief |
| 2026-06-26 08:34 | /novelty-check | idea-stage/BCE_GCL_NOVELTY_CHECK_20260626_083442.md | idea-discovery | BCE-GCL novelty-check report |
| 2026-06-26 08:34 | /novelty-check | idea-stage/BCE_GCL_NOVELTY_CHECK.md | idea-discovery | latest BCE-GCL novelty-check report |
| 2026-06-26 08:44 | /idea-discovery | research-wiki/ideas/bce_gcl.md | idea-discovery | pivoted BCE-GCL idea page |
| 2026-06-26 08:44 | /idea-discovery | research-wiki/ideas/cer_gcl.md | idea-discovery | CER-GCL pivot idea page |
| 2026-06-26 08:48 | /research-refine-pipeline | refine-logs/round-0-initial-proposal.md | implementation | initial CER-GCL proposal |
| 2026-06-26 08:50 | /research-refine-pipeline | refine-logs/round-1-review.md | implementation | first method review |
| 2026-06-26 08:50 | /research-refine-pipeline | refine-logs/round-1-refinement.md | implementation | revised CER-GCL proposal |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/round-2-review.md | implementation | re-evaluation approving pilot planning |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL_20260626_084754.md | implementation | timestamped final CER-GCL proposal |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL.md | implementation | latest final CER-GCL proposal |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/REVIEW_SUMMARY_20260626_084754.md | implementation | timestamped review summary |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/REVIEW_SUMMARY.md | implementation | latest review summary |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/REFINEMENT_REPORT_20260626_084754.md | implementation | timestamped refinement report |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/REFINEMENT_REPORT.md | implementation | latest refinement report |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/EXPERIMENT_PLAN_20260626_084754.md | implementation | timestamped pilot experiment plan |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/EXPERIMENT_PLAN.md | implementation | latest pilot experiment plan |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/EXPERIMENT_TRACKER_20260626_084754.md | implementation | timestamped experiment tracker |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/EXPERIMENT_TRACKER.md | implementation | latest experiment tracker |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/PIPELINE_SUMMARY_20260626_084754.md | implementation | timestamped pipeline summary |
| 2026-06-26 08:54 | /research-refine-pipeline | refine-logs/PIPELINE_SUMMARY.md | implementation | latest pipeline summary |
| 2026-06-26 08:55 | /render-html | idea-stage/IDEA_REPORT.html | idea-discovery | rendered HTML view of idea report |
| 2026-06-26 09:01 | /idea-creator | idea-stage/FRESH_GCL_IDEAS_20260626_090132.md | idea-generation | fresh GCL node-classification idea report excluding archived BCE/CER-GCL |
| 2026-06-26 09:01 | /idea-creator | idea-stage/FRESH_GCL_IDEAS.md | idea-generation | fixed entry for latest fresh GCL idea report |
| 2026-06-26 09:03 | /idea-discovery | idea-stage/IPU_GCL_NOVELTY_BRIEF_20260626_090347.md | novelty-check | interval / ambiguity-set GCL novelty reviewer brief |
| 2026-06-26 09:03 | /idea-discovery | idea-stage/IPU_GCL_NOVELTY_BRIEF.md | novelty-check | fixed entry for interval / ambiguity-set novelty brief |
| 2026-06-26 09:08 | /novelty-check | .aris/traces/novelty-check/2026-06-26_run02/ | novelty-check | fresh reviewer trace for IGT-GCL, verdict REVISE, score 5.5 |
| 2026-06-26 09:08 | /idea-discovery | idea-stage/IDEA_REPORT_20260626_090832.md | idea-discovery | fresh IGT-GCL idea report, excluding archived BCE/CER-GCL |
| 2026-06-26 09:08 | /idea-discovery | idea-stage/IDEA_REPORT.md | idea-discovery | latest fresh IGT-GCL idea report |
| 2026-06-26 09:08 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL_20260626_090832.md | refinement | timestamped IGT-GCL final proposal |
| 2026-06-26 09:08 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL.md | refinement | latest IGT-GCL final proposal |
| 2026-06-26 09:08 | /experiment-plan | refine-logs/EXPERIMENT_PLAN_20260626_090832.md | experiment-planning | timestamped IGT-GCL pilot experiment plan |
| 2026-06-26 09:08 | /experiment-plan | refine-logs/EXPERIMENT_PLAN.md | experiment-planning | latest IGT-GCL pilot experiment plan |
| 2026-06-26 09:08 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER_20260626_090832.md | experiment-planning | timestamped IGT-GCL experiment tracker |
| 2026-06-26 09:08 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER.md | experiment-planning | latest IGT-GCL experiment tracker |
| 2026-06-26 09:08 | /research-wiki | research-wiki/ideas/igt_gcl.md | wiki | active candidate idea page for IGT-GCL |
| 2026-06-26 09:14 | /render-html | idea-stage/IDEA_REPORT.html | idea-discovery | rendered HTML view of latest IGT-GCL idea report |
| 2026-06-26 09:21 | /idea-creator | idea-stage/FN_IDEAS_BEYOND_IGT_20260626_092155.md | idea-generation | timestamped false-negative GCL ideas beyond IGT-GCL |
| 2026-06-26 09:21 | /idea-creator | idea-stage/FN_IDEAS_BEYOND_IGT.md | idea-generation | fixed entry for false-negative GCL ideas beyond IGT-GCL |
| 2026-06-26 09:21 | /research-wiki | research-wiki/ideas/dsr_gcl.md | wiki | proposed top-1 idea page for DSR-GCL |
| 2026-06-26 09:21 | /research-wiki | research-wiki/ideas/cng_gcl.md | wiki | proposed top-2 idea page for CNG-GCL |
| 2026-06-26 09:24 | /idea-discovery | idea-stage/IDEA_CANDIDATES_20260626_092455.md | idea-generation | merged candidate ranking beyond IGT-GCL with SGF/DSR top idea |
| 2026-06-26 09:24 | /idea-discovery | idea-stage/IDEA_CANDIDATES.md | idea-generation | latest candidate pointer beyond IGT-GCL |
| 2026-06-26 09:24 | /novelty-check | idea-stage/DSR_GCL_NOVELTY_BRIEF_20260626_092455.md | novelty-check | DSR-GCL novelty-review brief |
| 2026-06-26 09:24 | /novelty-check | idea-stage/DSR_GCL_NOVELTY_BRIEF.md | novelty-check | latest DSR-GCL novelty-review brief |
| 2026-06-26 09:24 | /novelty-check | .aris/traces/novelty-check/2026-06-26_run03/ | novelty-check | fresh reviewer trace for DSR-GCL, verdict REVISE_IDEA, score 6.2 |
| 2026-06-26 09:24 | /idea-discovery | idea-stage/IDEA_REPORT_20260626_092455.md | idea-discovery | final idea report beyond IGT-GCL, decision REVISE_IDEA |
| 2026-06-26 09:24 | /idea-discovery | idea-stage/IDEA_REPORT.md | idea-discovery | latest idea report beyond IGT-GCL |
| 2026-06-26 09:24 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL_20260626_092455.md | refinement | timestamped DSR-GCL proposal |
| 2026-06-26 09:24 | /research-refine-pipeline | refine-logs/FINAL_PROPOSAL.md | refinement | latest DSR-GCL proposal |
| 2026-06-26 09:24 | /experiment-plan | refine-logs/EXPERIMENT_PLAN_20260626_092455.md | experiment-planning | timestamped DSR-GCL experiment plan |
| 2026-06-26 09:24 | /experiment-plan | refine-logs/EXPERIMENT_PLAN.md | experiment-planning | latest DSR-GCL experiment plan |
| 2026-06-26 09:24 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER_20260626_092455.md | experiment-planning | timestamped DSR-GCL tracker |
| 2026-06-26 09:24 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER.md | experiment-planning | latest DSR-GCL tracker |
| 2026-06-26 09:24 | /research-wiki | research-wiki/ideas/dsr_gcl.md | wiki | revised DSR-GCL idea page, decision REVISE_IDEA |
| 2026-06-26 09:30 | /render-html | idea-stage/IDEA_REPORT.html | idea-discovery | rendered HTML view of latest DSR-GCL idea report |
| 2026-06-26 09:40 | /research-refine | refine-logs/DSR_MECHANISM_SPEC_20260626_094055.md | refinement | timestamped DSR-GCL mechanism spec with math, pseudocode, diagnostics, and ablation matrix |
| 2026-06-26 09:40 | /research-refine | refine-logs/DSR_MECHANISM_SPEC.md | refinement | latest DSR-GCL mechanism spec |
| 2026-06-26 09:40 | /research-refine | refine-logs/FINAL_PROPOSAL_20260626_094055.md | refinement | timestamped mechanism-refined DSR-GCL proposal |
| 2026-06-26 09:40 | /research-refine | refine-logs/FINAL_PROPOSAL.md | refinement | latest mechanism-refined DSR-GCL proposal |
| 2026-06-26 09:40 | /experiment-plan | refine-logs/EXPERIMENT_PLAN_20260626_094055.md | experiment-planning | timestamped DSR-GCL smoke/pilot plan with A0-A11 ablations |
| 2026-06-26 09:40 | /experiment-plan | refine-logs/EXPERIMENT_PLAN.md | experiment-planning | latest DSR-GCL smoke/pilot plan with A0-A11 ablations |
| 2026-06-26 09:40 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER_20260626_094055.md | experiment-planning | timestamped DSR-GCL tracker with A0-A11 variants |
| 2026-06-26 09:40 | /experiment-plan | refine-logs/EXPERIMENT_TRACKER.md | experiment-planning | latest DSR-GCL tracker with A0-A11 variants |
| 2026-06-26 09:40 | /research-wiki | research-wiki/ideas/dsr_gcl.md | wiki | updated DSR-GCL idea page with parameter-isolated firewall definition |
| 2026-06-26 10:02 | manual-smoke | configs/dsr_smoke.yaml | smoke | DSR-GCL minimal smoke config for Cora seed 0 |
| 2026-06-26 10:02 | manual-smoke | scripts/run_dsr_smoke.py | smoke | DSR-GCL smoke runner reusing GRACE split/evaluator helpers |
| 2026-06-26 10:02 | manual-smoke | results/raw/Cora/DSR_GCL_SMOKE/dsr_smoke_Cora_seed0_20260626T095525Z/ | smoke | raw JSON results for A0/A2/A3/A4/A5/A9 |
| 2026-06-26 10:02 | manual-smoke | logs/dsr_smoke/dsr_smoke_Cora_seed0_20260626T095525Z/ | smoke | training JSONL logs for DSR-GCL smoke |
| 2026-06-26 10:02 | manual-smoke | results/summary/dsr_smoke_Cora_seed0_20260626T095525Z_summary.md | smoke | DSR-GCL smoke result and mechanism diagnostic table |
