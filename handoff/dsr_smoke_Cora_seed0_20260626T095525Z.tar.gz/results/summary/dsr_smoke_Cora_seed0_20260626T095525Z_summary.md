# DSR-GCL Smoke Summary

Scope: Cora seed=0 only, stratified random 1:1:8, frozen encoder + Logistic Regression.
Status: smoke/pilot diagnostic only; no formal result and no performance claim.

## Smoke Result Table

| ID | Variant | main z | valid@best | test@best | final test | z_sem | z_res | concat |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| A0 | grace_baseline | grace | 85.19 | 84.78 | 84.78 | NA | NA | NA |
| A2 | semantic_only_negative_free | z_sem | 77.78 | 78.27 | 78.27 | 78.27 | NA | NA |
| A3 | residual_only_infonce | z_res | 31.11 | 30.12 | 30.12 | NA | 30.12 | NA |
| A9 | dsr_full_firewall | concat | 75.93 | 77.08 | 77.08 | 78.27 | 32.29 | 77.08 |
| A5 | dsr_no_firewall_semantic_receives_negative | concat | 78.89 | 81.13 | 81.13 | 79.43 | 30.81 | 81.13 |
| A4 | same_parameter_single_head_control | single | 83.70 | 83.63 | 83.63 | NA | NA | NA |

## Mechanism Diagnostics

| ID | leak | firewall pass | rank_sem | rank_res | rank_concat | branch_corr | params |
|---|---:|---|---:|---:|---:|---:|---:|
| A0 | NA | NA | NA | NA | NA | NA | 4.33e+05 |
| A2 | NA | NA | 6.828 | NA | NA | NA | 2.001e+05 |
| A3 | NA | NA | NA | 2.59 | NA | NA | 2.001e+05 |
| A9 | 0 | True | 6.828 | 7.219 | 13.36 | 0.1168 | 4.003e+05 |
| A5 | 1.287 | False | 9.95 | 4.148 | 13.66 | 0.06594 | 4.003e+05 |
| A4 | NA | NA | NA | NA | NA | NA | 4.33e+05 |

## Kill Rule Readout

- C1 firewall diagnostic: PASS (A9 leak=0.0).
- A5 no-firewall check: A5 leak=1.2867257547899056, A9 leak=0.0.
- A2 semantic-only vs A9 full smoke gap: -1.20 points; single seed only.
- A4 same-head vs A9 full smoke gap: -6.55 points; single seed only.

Decision: `REVISE/PIVOT_REQUIRED` at smoke level; future pilots must first show stable mechanism advantage before any formal run.
