# FINAL_PROPOSAL: DSR-GCL

标题：**DSR-GCL: Decoupled Semantic-Residual Graph Contrastive Learning**  
核心机制：**Spectral Gradient Firewall**  
本轮 refinement：2026-06-26T09:40:55Z  
当前 decision：**REVISE_IDEA**  
证据等级：mechanism spec only；未实现代码、未跑实验、无性能 claim。

完整可实现机制规格见：

- `refine-logs/DSR_MECHANISM_SPEC.md`

## 1. Problem Anchor

节点级 GCL 的 false-negative 问题不只是“哪些其他节点被误当负样本”，而是 InfoNCE 的 negative repulsion 会作用在整条节点表示上。当同类或同语义节点被当作 negative 时，repulsive gradient 会撕裂节点分类所需的 semantic manifold。

DSR-GCL 的目标不是识别 false-negative pair，而是限制 negative repulsion 的作用通道：

```text
negative repulsion may shape residual/boundary representation,
but must not update semantic representation.
```

## 2. Fixed Mechanism Decision

本轮把 Spectral Gradient Firewall 固定为：

**parameter-isolated two-channel firewall**。

即首版默认不使用 shared trunk。两个通道参数隔离：

```text
Params(E_sem) ∩ Params(E_res) = ∅
Params(P_sem) ∩ Params(P_res) = ∅
```

并满足：

```text
∂L_res / ∂θ_sem = 0
∂L_sem / ∂θ_res = 0
```

这样回应 reviewer 指出的关键漏洞：shared encoder + two heads 不是 firewall，因为 residual InfoNCE 仍会通过 shared encoder 污染 semantic branch。

## 3. Architecture

给定两个增强视图：

```text
(X^1, A^1), (X^2, A^2)
```

构造低通与残差输入：

```text
S = D^{-1/2}(A + I)D^{-1/2}
P_L(X,A;K) = S^K X
P_R(X,A;K) = X - stopgrad(P_L(X,A;K))
```

两个通道：

```text
h_sem^v = E_sem(P_L(X^v,A^v;K), A^v)
h_res^v = E_res(P_R(X^v,A^v;K), A^v)
z_sem^v = normalize(P_sem(h_sem^v))
z_res^v = normalize(P_res(h_res^v))
```

默认维度：

```text
d_sem + d_res = d_base
d_sem = d_res = d_base / 2
```

参数量必须与 same-parameter single-head control 对齐。

## 4. Losses

Semantic branch 不使用 node-node negatives：

```text
L_sem = L_align + λ_var L_var + λ_cov L_cov
```

其中 `L_align` 是 cross-view positive-only alignment，`L_var/L_cov` 是 VICReg-style collapse guard。

Residual branch 使用 InfoNCE：

```text
L_res = InfoNCE(z_res^1, z_res^2)
```

Branch redundancy control：

```text
L_orth = || Corr(stopgrad(z_sem), z_res) ||_F^2
```

默认 `L_orth` 只更新 residual branch，避免给 semantic branch 引入 residual pressure。

总目标：

```text
L_total = L_sem + α L_res + β L_orth
```

默认：

```text
α = 1.0
β = 0.01
λ_var = 1.0
λ_cov = 1.0
```

## 5. Firewall Diagnostic

定义：

```text
θ_sem = Params(E_sem, P_sem)
θ_res = Params(E_res, P_res)
```

实现必须记录：

```text
firewall_leak_param =
  || grad(θ_sem; L_res) ||_2 / (|| grad(θ_res; L_res) ||_2 + eps)
```

默认 parameter-isolated 版本期望：

```text
firewall_leak_param < 1e-8
```

如果无法计算该诊断，不能声称实现了 Spectral Gradient Firewall。

## 6. Training Pseudocode

```python
def train_step(data):
    x1, edge1 = augment(data.x, data.edge_index)
    x2, edge2 = augment(data.x, data.edge_index)

    x1_sem = low_pass(x1, edge1, K)
    x2_sem = low_pass(x2, edge2, K)
    x1_res = x1 - stopgrad(x1_sem)
    x2_res = x2 - stopgrad(x2_sem)

    z1_sem = normalize(P_sem(E_sem(x1_sem, edge1)))
    z2_sem = normalize(P_sem(E_sem(x2_sem, edge2)))
    z1_res = normalize(P_res(E_res(x1_res, edge1)))
    z2_res = normalize(P_res(E_res(x2_res, edge2)))

    loss_sem = vicreg_semantic_loss(z1_sem, z2_sem)
    loss_res = info_nce(z1_res, z2_res, tau)
    loss_orth = corr_frobenius(stopgrad(z1_sem), z1_res)
    loss_orth += corr_frobenius(stopgrad(z2_sem), z2_res)

    loss = loss_sem + alpha * loss_res + beta * loss_orth

    diag["firewall_leak_param"] = grad_norm(theta_sem, loss_res) / (
        grad_norm(theta_res, loss_res) + eps
    )
    diag["rank_sem"] = effective_rank(cat(z1_sem, z2_sem))
    diag["rank_res"] = effective_rank(cat(z1_res, z2_res))
    diag["corr_sem_res"] = corr_frobenius(z1_sem.detach(), z1_res.detach())

    loss.backward()
    optimizer.step()
```

实际实现中可用 `torch.autograd.grad(loss_res, params, retain_graph=True, allow_unused=True)` 计算 leakage。

## 7. Evaluation Definition

默认预注册 evaluator embedding：

```text
z_eval = concat(z_sem, stopgrad(z_res))
```

必须额外记录诊断：

- `z_sem` only；
- `z_res` only；
- `concat(z_sem, z_res)`。

主口径不得用 test 选择。若未来要由 train/val 选择 `z_eval`，必须在所有方法上统一预注册。

## 8. Ablation Matrix

| ID | Variant | Exact change | Tests | Kill/Pivot signal |
|---|---|---|---|---|
| A0 | GRACE | Original InfoNCE | baseline | DSR no diagnostic advantage |
| A1 | GCA | adaptive augmentation | stronger GCL baseline | DSR only beats weak GRACE |
| A2 | Negative-free | `L_sem` only, same dim/params | residual necessity | matches full DSR |
| A3 | Residual-only | `L_res` only | semantic necessity | matches full DSR |
| A4 | Same-param single-head | one encoder/projector, same params | branch decoupling | matches full DSR |
| A5 | No firewall | apply InfoNCE to `z_sem` too | firewall necessity | no difference from full |
| A6 | No orthogonality | `β=0` | leakage/redundancy | matches or beats full |
| A7 | Random branch split | random split instead of low/residual | spectral split | matches full |
| A8 | Shared trunk | shared GNN + two heads | reviewer leakage risk | non-zero leakage, matches full |
| A9 | GraphRank residual | replace residual InfoNCE | not just InfoNCE | rank alone explains gains |
| A10 | Spectral fusion control | low/high fusion without firewall | not just spectral fusion | fusion matches full |
| A11 | Larger projector control | GRACE with matched params | parameter count | matches full |

Minimum smoke set:

```text
A0, A2, A5, A9
```

Minimum pilot set:

```text
A0, A1, A2, A3, A4, A5, A6, A7, A9, A11
```

## 9. Implementation Checklist

Before any coding:

- [ ] Fix `d_base`, `d_sem`, `d_res` from existing GRACE config.
- [ ] Use `P_L(X,A)=S X` as default low-pass.
- [ ] Use `P_R=X-stopgrad(P_L)` as default residual.
- [ ] Implement `firewall_leak_param` before running pilots.
- [ ] Pre-register `eval_embedding=concat`.
- [ ] Write configs for A0-A11 before training.
- [ ] Log parameter count, runtime, memory, raw JSON diagnostics.

## 10. Current Decision

**REVISE_IDEA**。

The mechanism is now concrete enough for a future smoke-only implementation request, but this document does not authorize full implementation, formal experiments, or any performance claim.

## 11. Smoke Addendum: 2026-06-26 Cora Seed 0

本轮仅完成最小 smoke，不是 formal 实验：

- config：`configs/dsr_smoke.yaml`
- runner：`scripts/run_dsr_smoke.py`
- summary：`results/summary/dsr_smoke_Cora_seed0_20260626T095525Z_summary.md`
- raw/logs：`results/raw/Cora/DSR_GCL_SMOKE/dsr_smoke_Cora_seed0_20260626T095525Z/`，`logs/dsr_smoke/dsr_smoke_Cora_seed0_20260626T095525Z/`

关键结论：

- A9 DSR-full 的 negative-gradient leakage 为 `0.0`，A5 no-firewall 为 `1.2867`，说明 firewall 诊断可测且能区分 no-firewall。
- 但 A9 concat `77.08` test@best 低于 A2 semantic-only `78.27`、A5 no-firewall `81.13`、A4 same-head `83.63` 和 A0 GRACE `84.78`。

更新后的阶段判断：**REVISE/PIVOT_REQUIRED**。当前证据只支持“firewall 诊断可实现”，不支持“DSR-full 机制有表现优势”。
