# EXPERIMENT_PLAN: DSR-GCL

生成时间：2026-06-26T09:40:55Z  
方法：DSR-GCL / Decoupled Semantic-Residual Graph Contrastive Learning  
核心机制：Spectral Gradient Firewall  
阶段：mechanism-refined plan only  
当前 decision：**REVISE_IDEA**  
禁止：不实现代码，不跑 formal，不产生性能 claim。

完整机制规格：

- `refine-logs/DSR_MECHANISM_SPEC.md`

## 1. Goal

未来 smoke/pilot 只回答一个问题：

> parameter-isolated Spectral Gradient Firewall 是否真的把 negative repulsion 限制在 residual channel，同时比 pure negative-free 和 same-param single-head 更有机制价值？

本计划不证明 SOTA，不支持论文性能 claim。

## 2. Protocol

- 同配图：stratified random `1:1:8` split。
- 异配图：官方或公认 fixed split。
- GCL evaluation：frozen encoder + Logistic Regression。
- evaluator 超参只能由 train/val 或 train-only CV 决定。
- pilot seeds 可从 `0,1,2` 开始；formal 若未来批准才用 `0-9`。
- 所有结果必须标注 smoke / pilot / development / formal。

## 3. Required Diagnostics

每次 run 必须保存：

- `firewall_leak_param = ||grad(theta_sem; L_res)|| / (||grad(theta_res; L_res)|| + eps)`。
- `rank_sem`, `rank_res`, `rank_concat`。
- `variance_sem`, `covariance_sem`。
- `corr_sem_res`。
- `alignment_sem`, `uniformity_res`, `uniformity_concat`。
- `logreg_acc_sem`, `logreg_acc_res`, `logreg_acc_concat`。
- parameter count, runtime, memory。
- config path, split path, seed, status label。

默认 firewall pass threshold:

```text
firewall_leak_param < 1e-8
```

若无法记录该值，不能进入 pilot。

## 4. Claim-to-Test Matrix

| ID | Mechanism claim | Required test | Kill / revise condition |
|---|---|---|---|
| C1 | negative gradient 不进入 semantic channel | A5 no-firewall and leakage diagnostic | leakage 非 0 或无法记录 -> REVISE |
| C2 | semantic branch 不只是 BGRL/CCA | A2 negative-free vs A9 full | A2 匹配 full -> PIVOT_REQUIRED |
| C3 | residual branch 提供 uniformity / boundary | A2/A3 vs full; uniformity/rank diagnostics | no-residual 匹配 -> REVISE |
| C4 | 不是参数量/双 head 效应 | A4 same-param single-head, A11 larger projector | controls 匹配 -> KILL/PIVOT |
| C5 | low/residual split 有意义 | A7 random split, A10 spectral fusion | controls 匹配 -> REVISE |
| C6 | 不只适合同配图 | Computers/Photo and optional heterophily fixed split | 明显退化 -> restrict or pivot |

## 5. Ablation IDs

| ID | Variant | Exact change | Required stage |
|---|---|---|---|
| A0 | GRACE | Original InfoNCE | smoke/pilot |
| A1 | GCA | Adaptive augmentation if available | pilot |
| A2 | Negative-free | `L_sem` only, same dim/params | smoke/pilot |
| A3 | Residual-only | `L_res` only | pilot |
| A4 | Same-param single-head | one encoder/projector, same params, mixed loss | pilot |
| A5 | No firewall | apply InfoNCE to `z_sem` too | smoke/pilot |
| A6 | No orthogonality | `β=0` | pilot |
| A7 | Random branch split | random feature/channel split instead of low/residual | pilot |
| A8 | Shared trunk | shared GNN + two heads | optional diagnostic |
| A9 | Full DSR | parameter-isolated semantic/residual + firewall + orth | smoke/pilot |
| A10 | Spectral fusion control | low/high fusion without firewall | optional pilot |
| A11 | Larger projector control | GRACE with matched params | pilot |

Minimum smoke set:

```text
A0, A2, A5, A9
```

Minimum pilot set:

```text
A0, A1, A2, A3, A4, A5, A6, A7, A9, A11
```

## 6. Dataset Schedule

| Stage | Dataset | Split | Seeds | Variants | Purpose |
|---|---|---|---|---|---|
| Smoke | Cora | `1:1:8` | 0 | A0,A2,A5,A9 | check mechanics and diagnostics |
| Pilot-A | Cora,CiteSeer,PubMed | `1:1:8` | 0,1,2 | minimum pilot set | mechanism screening |
| Pilot-B | Computers,Photo | `1:1:8` | 0,1,2 | A0,A2,A4,A5,A9,A11 | transfer beyond Planetoid |
| Optional | heterophily benchmark | official fixed | official seeds | A0,A2,A5,A9 | high-frequency classification risk |

## 7. Stage Gates

### Gate 0: Pre-Implementation

Pass only if:

- `DSR_MECHANISM_SPEC.md` accepted as implementation contract。
- `eval_embedding=concat` pre-registered。
- A0-A11 configs are drafted before training。
- split files exist or generation protocol is fixed。

### Gate 1: Smoke

Pass only if:

- no NaN；
- `firewall_leak_param` recorded；
- `z_sem` and `z_res` non-collapse；
- frozen Logistic Regression evaluator works；
- raw JSON saved。

### Gate 2: Pilot Mechanism

Pass only if:

- A9 differs from A5 in firewall diagnostic and semantic health；
- A9 not matched by A2/A4/A11；
- A7 does not match A9；
- negative and failed results preserved。

### Gate 3: Experiment Bridge

Current state does not satisfy this gate. `GO_TO_EXPERIMENT_BRIDGE` requires reviewer re-check and experiment-audit after smoke/pilot support.

## 8. Current Decision

**REVISE_IDEA**。

The mechanism is now specified tightly enough for future smoke implementation, but not for formal experiments or claims.

## 9. Smoke Addendum: 2026-06-26 Cora Seed 0

已完成一次最小 smoke：

- dataset / split / seed：Cora，stratified random `1:1:8`，seed `0`。
- evaluator：frozen encoder + Logistic Regression，`C` 由 validation accuracy 选择。
- variants：A0, A2, A3, A4, A5, A9。
- summary：`results/summary/dsr_smoke_Cora_seed0_20260626T095525Z_summary.md`。
- raw：`results/raw/Cora/DSR_GCL_SMOKE/dsr_smoke_Cora_seed0_20260626T095525Z/`。

Gate-1 机械诊断部分通过：A9 `negative_gradient_leakage=0.0`，A5 no-firewall `negative_gradient_leakage=1.2867`。但机制优势未通过 smoke：A9 concat `77.08` test@best 低于 A2 semantic-only `78.27`、A5 no-firewall `81.13`、A4 same-head `83.63` 和 A0 GRACE `84.78`。

更新后的阶段判断：**REVISE/PIVOT_REQUIRED**。禁止据此进入 formal 或产生性能 claim。
