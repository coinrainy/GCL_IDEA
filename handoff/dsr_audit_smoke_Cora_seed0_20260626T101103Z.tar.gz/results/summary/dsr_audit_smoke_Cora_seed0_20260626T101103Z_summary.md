# DSR-GCL Audit-Smoke Summary

Scope: Cora seed=0 only, stratified random 1:1:8, frozen encoder + Logistic Regression.
Status: audit-smoke diagnostic only; no formal result and no performance claim.

## Audit Notes

- Previous A9 DSR-full result was poor relative to A2/A5/A4/A0.
- A3 residual-only was almost ineffective, so residual utility is under question.
- Previous A5 was unfair because it added semantic InfoNCE on top of residual InfoNCE.
- Previous A4 was not strictly parameter-matched to A9; this run adds A4b.
- This summary explicitly reports embedding-level results, params, ranks, leakage, raw JSON, and logs.

## Complete Result Table

| ID | Variant | main z | valid@best | test@best | final test | params | raw JSON | log |
|---|---|---:|---:|---:|---:|---:|---|---|
| A0 | grace_baseline | grace | 85.19 | 84.78 | 84.78 | 433024 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A0_grace_baseline.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A0_grace_baseline.jsonl` |
| A2 | semantic_only_negative_free | z_sem | 77.78 | 78.27 | 78.27 | 200128 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A2_semantic_only_negative_free.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A2_semantic_only_negative_free.jsonl` |
| A3 | residual_only_infonce | z_res | 30.37 | 30.21 | 30.21 | 200128 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A3_residual_only_infonce.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A3_residual_only_infonce.jsonl` |
| A9 | dsr_full_firewall | concat | 76.30 | 78.69 | 78.69 | 400256 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A9_dsr_full_firewall.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A9_dsr_full_firewall.jsonl` |
| A5 | dsr_no_firewall_semantic_receives_negative | concat | 78.89 | 80.95 | 80.95 | 400256 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5_dsr_no_firewall_semantic_receives_negative.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5_dsr_no_firewall_semantic_receives_negative.jsonl` |
| A5a | semantic_infonce_only | z_sem | 78.52 | 79.43 | 79.43 | 200128 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5a_semantic_infonce_only.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5a_semantic_infonce_only.jsonl` |
| A5b | budget_matched_no_firewall | concat | 78.89 | 79.57 | 79.57 | 400256 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5b_budget_matched_no_firewall.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5b_budget_matched_no_firewall.jsonl` |
| A5c | scaled_no_firewall | concat | 78.89 | 81.00 | 81.00 | 400256 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5c_scaled_no_firewall.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A5c_scaled_no_firewall.jsonl` |
| A4 | same_parameter_single_head_control | single | 83.70 | 83.63 | 83.63 | 433024 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A4_same_parameter_single_head_control.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A4_same_parameter_single_head_control.jsonl` |
| A4b | param_matched_single_head | single | 83.33 | 80.81 | 80.81 | 402120 | `/root/autodl-tmp/GCL_IDEA/results/raw/Cora/DSR_GCL_SMOKE/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A4b_param_matched_single_head.json` | `/root/autodl-tmp/GCL_IDEA/logs/dsr_smoke/dsr_audit_smoke_Cora_seed0_20260626T101103Z/A4b_param_matched_single_head.jsonl` |

## Embedding-Level Table

| ID | z_sem test | z_res test | concat test | grace test | single test | rank_sem | rank_res | rank_concat | rank_single | branch_corr |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A0 | NA | NA | NA | 84.78 | NA | NA | NA | NA | NA | NA |
| A2 | 78.27 | NA | NA | NA | NA | 6.828 | NA | NA | NA | NA |
| A3 | NA | 30.21 | NA | NA | NA | NA | 2.588 | NA | NA | NA |
| A9 | 78.27 | 30.35 | 78.69 | NA | NA | 6.828 | 5.821 | 12.15 | NA | 0.1196 |
| A5 | 79.43 | 31.32 | 80.95 | NA | NA | 9.949 | 3.02 | 12.51 | NA | 0.06565 |
| A5a | 79.43 | NA | NA | NA | NA | 9.949 | NA | NA | NA | NA |
| A5b | 79.52 | 30.21 | 79.57 | NA | NA | 9.688 | 12.8 | 9.784 | NA | 0.0007716 |
| A5c | 81 | 30.21 | 81 | NA | NA | 9.714 | 9.622 | 9.794 | NA | 0.0006978 |
| A4 | NA | NA | NA | NA | 83.63 | NA | NA | NA | 24.24 | NA |
| A4b | NA | NA | NA | NA | 80.81 | NA | NA | NA | 21.38 | NA |

## Parameter Count Table

| ID | Variant | params | target params | abs gap | rel gap | hidden dim | note |
|---|---|---:|---:|---:|---:|---:|---|
| A0 | grace_baseline | 4.33e+05 | NA | NA | NA | NA |  |
| A2 | semantic_only_negative_free | 2.001e+05 | NA | NA | NA | NA |  |
| A3 | residual_only_infonce | 2.001e+05 | NA | NA | NA | NA |  |
| A9 | dsr_full_firewall | 4.003e+05 | NA | NA | NA | NA |  |
| A5 | dsr_no_firewall_semantic_receives_negative | 4.003e+05 | NA | NA | NA | NA | unfair_extra_semantic_infonce_budget |
| A5a | semantic_infonce_only | 2.001e+05 | NA | NA | NA | NA |  |
| A5b | budget_matched_no_firewall | 4.003e+05 | NA | NA | NA | NA |  |
| A5c | scaled_no_firewall | 4.003e+05 | NA | NA | NA | NA |  |
| A4 | same_parameter_single_head_control | 4.33e+05 | NA | NA | NA | 128 | not_strictly_parameter_matched_to_A9 |
| A4b | param_matched_single_head | 4.021e+05 | 4.003e+05 | 1864 | 0.004657 | 120 |  |

## Leakage Table

| ID | leak | sem grad | res grad | firewall pass | res weight | sem weight | loss scale |
|---|---:|---:|---:|---|---:|---:|---:|
| A0 | NA | NA | NA | NA | NA | NA | NA |
| A2 | NA | NA | NA | NA | NA | NA | 1 |
| A3 | NA | NA | NA | NA | 1 | NA | 1 |
| A9 | 0 | 0 | 21.34 | True | 1 | NA | 1 |
| A5 | 2.478 | 6.321 | 2.551 | False | 1 | 1 | 1 |
| A5a | NA | NA | NA | NA | NA | 1 | 1 |
| A5b | 1.165e+04 | 2.998 | 0.0002563 | False | 0.5 | 0.5 | 1 |
| A5c | 1.125e+04 | 6.144 | 0.0005452 | False | 1 | 1 | 0.5974 |
| A4 | NA | NA | NA | NA | NA | NA | NA |
| A4b | NA | NA | NA | NA | NA | NA | NA |

## Kill Rule Readout

- C1 firewall diagnostic: PASS (A9 leak=0.0).
- A5 no-firewall check: A5 leak=2.4781254819523917, A9 leak=0.0.
- A2 semantic-only vs A9 full smoke gap: 0.42 points; single seed only.
- A3 residual-only test@best: 30.21; single seed only.
- A4 same-head vs A9 full smoke gap: -4.94 points; single seed only.
- A4b param-matched same-head vs A9 full smoke gap: -2.12 points; single seed only.
- A5b fairer no-firewall vs A9 full smoke gap: -0.88 points; single seed only.
- A5c fairer no-firewall vs A9 full smoke gap: -2.31 points; single seed only.
- Triggered rules: `A3_residual_only_near_random_or_extremely_low, A9_below_A4_same_head, A9_below_A4b_param_matched_single_head, A5b_above_A9_firewall_claim_not_supported, A5c_above_A9_firewall_claim_not_supported`.

Decision: `PIVOT_REQUIRED`. 不建议继续推进 DSR-GCL formal；应先重构 residual branch 或放弃当前 firewall 叙事。
